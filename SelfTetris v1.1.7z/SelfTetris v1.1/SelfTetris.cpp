/* SelfTetris.cpp */

#include "SelfTetris.h"

int SelfTetris::Rectangle(int i,int j,int isStill)
{
	isStill=isStill?GRAY_BRUSH:WHITE_BRUSH;
	SelectObject (hdc, GetStockObject (isStill)) ;
	::Rectangle(hdc,PV(j),PV(i),PV(j+1),PV(i+1));
	SelectObject (hdc, GetStockObject (GRAY_BRUSH)) ;
	return 0;
}
int SelfTetris::IsMove(int x,int y)
{
	BIN_FOR_BEGINE(i,j,H_NUM,W_NUM)
		if((board[i][j]==2)&&((i+y>=H_NUM||i+y<=-1)||(board[i+y][j+x]==1)))
			return -1;
		else if((board[i][j]==2)&&((j+x>=W_NUM||j+x<=-1)))
			return 0;
	return 1;
}
int SelfTetris::IsDis(int y)
{
	for(j=0;j!=W_NUM;j++)
		if(board[y][j]!=1) return 0;
	for(j=0;j!=W_NUM;j++) board[y][j]=0;
	for(int i=y-1;i!=-1;--i)
		for(int j=0;j!=W_NUM;++j)
			if(board[i][j]==1)
			{
				board[i+1][j]=1;
				i>=H_HIDE?Rectangle(i+1,j,1):1;
				board[i][j]=0;
			}
			return 1;
}
int SelfTetris::GoCurdle(int x,int y,int isFall,int isX)
{
	int tag=0,a,b,d;
	a=W_NUM-1,b=-1,d=-1;
	if(x==-1) b=W_NUM-1,a=0,d=1;
	for(i=H_NUM-1;i!=-1;--i)
		for(j=a;j!=b;j+=d)
			if(board[i][j]==2)
			{
				if(isFall==-1){
					canDrop=1;
					board[i][j]=1;
					i>=H_HIDE&&isX==0?Rectangle(i,j,1):1; 
				}else  if(isFall==1)
				{
					board[i+y][j+x]=2,board[i][j]=0;
					i>=H_HIDE&&isX==0?Rectangle(i+y,j+x,0):1; 
					tag=1;
				}
			}else if(board[i][j]==1)
				i>=H_HIDE&&isX==0?Rectangle(i,j,1):1;
	if(tag==1) _x+=x,_y+=y;
	if(isX==0)
	  BIN_FOR_BEGINE(i,j,4,4)
		Rectangle(H_NUM/2+4+i,W_NUM+4+j,!(obj[i][j]==1));
	return isFall;
}
void SelfTetris::KeyDown(WPARAM wparam)
{
	switch (wparam)
	{
	case 0x41:i=-1;break;
	case 0x57: RotateBlocks();break;
	case 0x53:i=2;break;
	case 0x44:i=1;
	}
}
void SelfTetris::Run(int x,int y,int isX)
{	
	SelectObject (hdc, GetStockObject (BLACK_PEN)) ;
	::Rectangle(hdc,DELTA_LEFTTOP,DELTA_LEFTTOP+H_HIDE*D_LEN,DELTA_LEFTTOP+W_NUM*D_LEN,DELTA_LEFTTOP+H_NUM*D_LEN);
	SelectObject (hdc, GetStockObject (GRAY_BRUSH)) ;
	int mul=0;
	GoCurdle(x,y,IsMove(x,y),isX);
	for(i=0;i!=H_NUM;i++)
		IsDis(i)?++mul>=2?scores+=10*mul:scores+=10:1;
	static wchar_t str[40];
	SelectObject (hdc, GetStockObject (BLACK_PEN));
	wsprintf(str,L" Total Score : %d ",scores);
	TextOut(hdc,320,200,str,wcslen(str));
	wsprintf(str,L" Game Level : %d ",scores/10+1);
	TextOut(hdc,320,250,str,wcslen(str));
}

void SelfTetris::RotateBlocks()
{
	int _board[H_NUM][W_NUM]={0};
	BIN_FOR_BEGINE(x,y,H_NUM,W_NUM)
		if(board[x][y]==2)
			if((_x+_y-x)>=W_NUM||(_x+_y-x)<=-1||(_y-(_x-y))>=H_NUM||
				(_y-(_x-y))<=-1||board[_y-(_x-y)][_x+(_y-x)]==1)
				return;
	BIN_FOR_BEGINE(x,y,H_NUM,W_NUM)
		if(board[x][y]==2)
			board[x][y]=0,_board[_y-(_x-y)][_x+(_y-x)]=2;
	BIN_FOR_BEGINE(x,y,H_NUM,W_NUM)
		if(_board[x][y]==2)
			board[x][y]=_board[x][y];
}
void SelfTetris::SetBlocks(int mx,int my)
{
	BIN_FOR_BEGINE(x,y,4,4)
		if(my>PV(H_NUM/2+4+x)&&
			my<PV(H_NUM/2+4+x+1)&&
			mx>PV(W_NUM+4+y)&&
			mx<PV(W_NUM+4+y+1))
			obj[x][y]=(obj[x][y]+1)%2;
}
void SelfTetris::CastBlocks()
{
	if(canDrop==0)
		return;
	BIN_FOR_BEGINE(x,y,4,4)
		if(obj[x][y]==1)
			board[0+x][W_NUM/2+y]=2;
	canDrop=0;
	_x=W_NUM/2+2;
	_y=2;
}
void SelfTetris::Action()
{
	if(i==2)  Run(0,1,1);
	else if(i!=0) Run(i,0,1);
	for(x=0;x!=scores/10+1;x++)
		Run(0,1,0);
	i=0;
}
SelfTetris::SelfTetris(int dtime_)
{
	canDrop=0;
	memset(obj,0,sizeof(int)*16);
	memset(board,0,sizeof(int)*H_NUM*W_NUM);
	board[0][W_NUM/2-1]=board[0][W_NUM/2+2]=board[0][W_NUM/2+4]=board[0][W_NUM/2+3]=2;
	_x=W_NUM/2+2;
	_y=2;
	i=j=0;
	scores=0;
	dtime=dtime_;
}