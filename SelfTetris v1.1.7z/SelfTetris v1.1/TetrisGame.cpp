/* TetrisGame.cpp */

#include  "SelfTetris.h"

SelfTetris aTetris(100);

LRESULT CALLBACK WindowProc(HWND hwnd,UINT msg,WPARAM wparam,LPARAM lparam)
{
	aTetris.hdc=GetDC(hwnd);
	int	mx = (int)LOWORD(lparam),my = (int)HIWORD(lparam);
	switch(msg)
	{
	case WM_KEYDOWN:
		aTetris.KeyDown(wparam);
		break;
	case WM_LBUTTONDOWN:
		aTetris.SetBlocks(mx,my);
		break;
	case WM_RBUTTONUP:
		aTetris.CastBlocks();
		break;
	case WM_CREATE:
		SetTimer(hwnd,10,100,0);
		break;
	case WM_TIMER:
		aTetris.Action();
		break;
	case WM_PAINT:
		break;
	case WM_DESTROY:PostQuitMessage(0);
		break;
	default:break;
	}
	ReleaseDC(hwnd,aTetris.hdc);
	return (DefWindowProc(hwnd, msg, wparam, lparam));
} 


int WINAPI WinMain(HINSTANCE hinstance,HINSTANCE hprevinstance,LPSTR lpcmdline,int ncmdshow)
{
	WNDCLASSEX winclass={sizeof(WNDCLASSEX),CS_DBLCLKS | CS_OWNDC | CS_HREDRAW | CS_VREDRAW,
		WindowProc,0,0,hinstance,LoadIcon(NULL, IDI_APPLICATION),
		LoadCursor(NULL, IDC_ARROW),(HBRUSH__*)GetStockObject(BLACK_BRUSH),0,
		L"SelfTetris",0};
	HWND  hwnd;   
	MSG   msg;   
	if (!RegisterClassEx(&winclass))
		return 0;
	if (!(hwnd = CreateWindowEx(NULL,L"SelfTetris",L"SelfTetris",
		WS_OVERLAPPEDWINDOW | WS_VISIBLE,0,0,455,600,NULL,NULL,hinstance,NULL)))   
		return 0;

	while(TRUE)
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	return msg.wParam;
} 